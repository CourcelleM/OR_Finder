# To Do

## Improvements

* Replace FASTA by BLAST or faster approach that doesn't change executable filenames
* Improve installation and deployment
* Add a docker deployment
* Remove BioPerl
* Move to Python3 (for speed and flexibility)

## Better Model

* Update OR HMM with recent OR gene sequences from the vast genomic resources
* Add a Vomeronasal receptor gene module
